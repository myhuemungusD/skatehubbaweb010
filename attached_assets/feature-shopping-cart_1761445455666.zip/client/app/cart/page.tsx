"use client";
import { useCart } from "@/client/lib/cart/store";

export default function CartPage() {
  const { snapshot, remove, setQty, clear } = useCart();
  const snap = snapshot();

  return (
    <main className="mx-auto max-w-3xl p-4">
      <h1 className="text-2xl font-bold mb-4">Checkout</h1>

      {snap.items.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <>
          <table className="w-full text-left">
            <thead>
              <tr className="border-b">
                <th className="py-2">Product</th>
                <th className="py-2">Price</th>
                <th className="py-2">Qty</th>
                <th className="py-2">Total</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {snap.items.map((i) => (
                <tr key={i.id} className="border-b">
                  <td className="py-2">{i.name}</td>
                  <td className="py-2">${i.price.toFixed(2)}</td>
                  <td className="py-2">
                    <input
                      type="number"
                      min={1}
                      value={i.quantity}
                      onChange={(e) => setQty(i.id, Number(e.target.value))}
                      className="w-20 rounded border px-2 py-1"
                    />
                  </td>
                  <td className="py-2">${(i.price * i.quantity).toFixed(2)}</td>
                  <td className="py-2">
                    <button onClick={() => remove(i.id)} className="text-red-600">Remove</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="mt-6 flex items-center justify-between">
            <button onClick={clear} className="rounded border px-3 py-2">Clear cart</button>
            <div className="text-xl font-semibold">Subtotal ${snap.subtotal.toFixed(2)}</div>
          </div>

          <button
            onClick={() => alert(`Proceeding to payment. Subtotal $${snap.subtotal.toFixed(2)}`)}
            className="mt-4 w-full rounded bg-black text-white px-4 py-3 text-lg"
          >
            Pay now
          </button>
        </>
      )}
    </main>
  );
}
