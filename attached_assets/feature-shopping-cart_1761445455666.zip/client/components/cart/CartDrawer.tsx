"use client";
import { useEffect, useRef, useState } from "react";
import { useCart } from "@/client/lib/cart/store";

export default function CartDrawer() {
  const { snapshot, remove, setQty, clear } = useCart();
  const [open, setOpen] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const snap = snapshot();

  useEffect(() => {
    function onEsc(e: KeyboardEvent) { if (e.key === "Escape") setOpen(false); }
    window.addEventListener("keydown", onEsc);
    return () => window.removeEventListener("keydown", onEsc);
  }, []);

  return (
    <>
      <button
        aria-label="Open cart"
        onClick={() => setOpen(true)}
        className="relative inline-flex items-center gap-2 rounded border px-3 py-2"
      >
        Cart
        <span className="inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-black text-white text-xs px-1">
          {snap.count}
        </span>
      </button>

      {open && (
        <div className="fixed inset-0 z-50">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => setOpen(false)}
            aria-hidden
          />
          <div
            ref={panelRef}
            className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-xl p-4 overflow-y-auto"
            role="dialog"
            aria-modal="true"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Your Cart</h2>
              <button onClick={() => setOpen(false)} className="p-2">✕</button>
            </div>

            {snap.items.length === 0 ? (
              <p className="text-sm text-gray-600">Your cart is empty.</p>
            ) : (
              <ul className="space-y-3">
                {snap.items.map((i) => (
                  <li key={i.id} className="flex gap-3">
                    {i.image ? (
                      <img src={i.image} alt={i.name} className="h-16 w-16 object-cover rounded" />
                    ) : (
                      <div className="h-16 w-16 bg-gray-200 rounded" />
                    )}
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <p className="font-medium">{i.name}</p>
                        <button onClick={() => remove(i.id)} className="text-sm text-red-600">Remove</button>
                      </div>
                      <p className="text-sm">${i.price.toFixed(2)}</p>
                      <div className="mt-2 flex items-center gap-2">
                        <label className="text-sm">Qty</label>
                        <input
                          type="number"
                          min={1}
                          value={i.quantity}
                          onChange={(e) => setQty(i.id, Number(e.target.value))}
                          className="w-16 rounded border px-2 py-1 text-sm"
                        />
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}

            <div className="mt-6 border-t pt-4">
              <div className="flex justify-between text-base">
                <span>Subtotal</span>
                <span className="font-semibold">${snap.subtotal.toFixed(2)}</span>
              </div>
              <div className="mt-4 flex gap-2">
                <button onClick={clear} className="w-1/3 rounded border px-3 py-2">Clear</button>
                <a
                  href="/cart"
                  className="w-2/3 text-center rounded bg-black text-white px-3 py-2"
                  onClick={() => setOpen(false)}
                >
                  Go to Checkout
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
