"use client";
import { useCart } from "@/client/lib/cart/store";
import type { CartItem } from "@/client/lib/cart/types";

export default function AddToCartButton(props: CartItem) {
  const add = useCart((s) => s.add);
  return (
    <button
      onClick={() => add({ ...props, quantity: Math.max(1, props.quantity || 1) })}
      className="rounded bg-black text-white px-3 py-2"
    >
      Add to Cart
    </button>
  );
}
